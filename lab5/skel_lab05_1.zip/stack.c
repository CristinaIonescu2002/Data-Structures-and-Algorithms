#include <stdlib.h>
#include "stack.h"

void push(stack_t *stack, int value) {
    /*
     * TODO
     *      Se adauga un nou nod cu valoarea data
     *      ca parametru la inceputul listei
     */
}

int pop(stack_t *stack, int *status) {
    /*
     * TODO
     *      Se elimina nodul din varful stivei si i se returneaza valoarea
     *          - Daca stiva este goala, se seteaza parametrul 'status' la valoarea STATUS_ERR (1)
     *          - Altfel, se seteaza parametrul 'status' la valoarea STATUS_OK (0)
     */
    return 0;
}

int top(stack_t *stack, int *status) {
    /*
     * TODO
     *      Se returneaza valoarea nodul din varful stivei
     *          - Daca stiva este goala, se seteaza parametrul 'status' la valoarea STATUS_ERR (1)
     *          - Altfel, se seteaza parametrul 'status' la valoarea STATUS_OK (0)
     */
    return 0;
}

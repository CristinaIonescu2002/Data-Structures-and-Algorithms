#include <stdio.h>
#include <stdlib.h>

#include "lab05.h"
#include "list.h"
#include "stack.h"
#include "queue.h"

#define NUM_QUEUES 10

int checkBalancedBrackets(char *exp) {
    /*
     * TODO Exercitiul 3
     */
    return 0;
}

void radixSort(int *v, int n) {
    /*
     * TODO Exercitiul 4
     */
}
